<?php
$dns = "mysql:host=localhost;dbname=class";
$user = "root";
$pass = "";
$dbh = new PDO($dns,$user,$pass);